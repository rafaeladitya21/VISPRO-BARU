<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;

Route::get('/', function () {
    return redirect()->route('karyawan.index');
});

Route::resource('karyawan', EmployeeController::class)->parameters([
    'karyawan' => 'employee'
]);git