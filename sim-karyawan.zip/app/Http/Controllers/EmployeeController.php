<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Storage;
use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        // Menggunakan pagination agar performa tetap baik saat data membesar
        $employees = Employee::latest()->paginate(10);
        return view('karyawan.index', compact('employees'));
    }

    public function create()
    {
        return view('karyawan.create');
    }

   public function store(Request $request)
    {
        $validated = $request->validate([
            'nip' => 'required|string|max:20|unique:employees,nip',
            'nama_lengkap' => 'required|string|max:255',
            'email' => 'required|email|unique:employees,email',
            'jabatan' => 'required|string|max:100',
            'departemen' => 'required|string|max:100',
            'tanggal_bergabung' => 'required|date',
            // Validasi file: maksimal 2MB, format PDF/DOC/DOCX/JPG/PNG
            'dokumen_lampiran' => 'nullable|file|mimes:pdf,doc,docx,jpg,png|max:2048', 
        ]);

        // Logika Upload File
        if ($request->hasFile('dokumen_lampiran')) {
            $file = $request->file('dokumen_lampiran');
            $filename = time() . '_' . $file->getClientOriginalName();
            // Simpan ke storage/app/public/dokumen
            $path = $file->storeAs('dokumen', $filename, 'public'); 
            $validated['dokumen_lampiran'] = $path;
        }

        Employee::create($validated);

        return redirect()->route('karyawan.index')->with('success', 'Data karyawan berhasil ditambahkan.');
    }
    
    // Pada method edit
public function edit(Employee $employee)
{
    return view('karyawan.edit', compact('employee'));
}

    public function update(Request $request, Employee $employee)
    {
        $validated = $request->validate([
            'nip' => 'required|string|max:20|unique:employees,nip,' . $employee->id,
            'nama_lengkap' => 'required|string|max:255',
            'email' => 'required|email|unique:employees,email,' . $employee->id,
            'jabatan' => 'required|string|max:100',
            'departemen' => 'required|string|max:100',
            'tanggal_bergabung' => 'required|date',
            'dokumen_lampiran' => 'nullable|file|mimes:pdf,doc,docx,jpg,png|max:2048',
        ]);

        // Logika Update File
        if ($request->hasFile('dokumen_lampiran')) {
            // Hapus file lama jika ada
            if ($employee->dokumen_lampiran && Storage::disk('public')->exists($employee->dokumen_lampiran)) {
                Storage::disk('public')->delete($employee->dokumen_lampiran);
            }

            $file = $request->file('dokumen_lampiran');
            $filename = time() . '_' . $file->getClientOriginalName();
            $path = $file->storeAs('dokumen', $filename, 'public');
            $validated['dokumen_lampiran'] = $path;
        }

        $employee->update($validated);

        return redirect()->route('karyawan.index')->with('success', 'Data karyawan berhasil diperbarui.');
    }

    public function destroy(Employee $employee)
    {
        $employee->delete();
        return redirect()->route('karyawan.index')->with('success', 'Data karyawan berhasil dihapus.');
    }
}