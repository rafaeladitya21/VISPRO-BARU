<div class="form-section mb-5">
    <h6 class="section-title text-uppercase text-primary mb-1" style="font-size: 0.8rem; letter-spacing: 1px; font-weight: 700;">
        01. Identitas Utama
    </h6>
    <h4 class="h5 mb-4" style="font-weight: 600; color: #1e293b;">Siapa karyawan yang akan didaftarkan/diubah?</h4>
    
    <div class="row g-4">
        <div class="col-md-4">
            <label class="form-label required">Nomor Induk Pegawai (NIP)</label>
            <input type="text" name="nip" class="form-control <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Contoh: 77777777" value="<?php echo e(old('nip', $employee->nip ?? '')); ?>">
            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="col-md-8">
            <label class="form-label required">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" class="form-control <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Masukkan nama sesuai KTP" value="<?php echo e(old('nama_lengkap', $employee->nama_lengkap ?? '')); ?>">
            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-12">
            <label class="form-label required">Alamat Email Perusahaan</label>
            <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="nama@perusahaan.com" value="<?php echo e(old('email', $employee->email ?? '')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>

<hr class="my-5" style="border-top: 1px dashed #cbd5e1; opacity: 0.6;">

<div class="form-section mb-5">
    <h6 class="section-title text-uppercase text-primary mb-1" style="font-size: 0.8rem; letter-spacing: 1px; font-weight: 700;">
        02. Penugasan & Jabatan
    </h6>
    <h4 class="h5 mb-4" style="font-weight: 600; color: #1e293b;">Di mana posisi dan kapan karyawan mulai bekerja?</h4>

    <div class="row g-4">
        <div class="col-md-6">
            <label class="form-label required">Departemen / Divisi</label>
            <input type="text" name="departemen" class="form-control <?php $__errorArgs = ['departemen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Contoh: Teknologi Informasi, Kreatif" value="<?php echo e(old('departemen', $employee->departemen ?? '')); ?>">
            <?php $__errorArgs = ['departemen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label class="form-label required">Jabatan Resmi</label>
            <input type="text" name="jabatan" class="form-control <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   placeholder="Contoh: Senior Developer, Lead Videographer" value="<?php echo e(old('jabatan', $employee->jabatan ?? '')); ?>">
            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-md-6">
            <label class="form-label required">Tanggal Bergabung</label>
            <div class="input-group">
                <input type="date" name="tanggal_bergabung" class="form-control <?php $__errorArgs = ['tanggal_bergabung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('tanggal_bergabung', $employee->tanggal_bergabung ?? '')); ?>">
            </div>
            <?php $__errorArgs = ['tanggal_bergabung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>

<hr class="my-5" style="border-top: 1px dashed #cbd5e1; opacity: 0.6;">
<div class="form-section mb-5">
    <h6 class="section-title text-uppercase text-primary mb-1" style="font-size: 0.8rem; letter-spacing: 1px; font-weight: 700;">
        03. Dokumen Lampiran
    </h6>
    <h4 class="h5 mb-4" style="font-weight: 600; color: #1e293b;">Apakah ada contoh berkas atau dokumen pendukung?</h4>

    <div class="upload-zone p-5 text-center mb-4">
        <div class="d-flex flex-column flex-sm-row justify-content-center align-items-center gap-3">
            
            <input type="file" name="dokumen_lampiran" id="dokumen_lampiran" class="d-none <?php $__errorArgs = ['dokumen_lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept=".pdf,.doc,.docx,.jpg,.png">
            
            <button type="button" onclick="document.getElementById('dokumen_lampiran').click()" class="btn btn-outline-primary px-4 py-2" style="font-weight: 600; border-radius: 8px;">
                Unggah Dokumen
            </button>
            
            <span id="file-name-preview" class="text-muted" style="font-size: 0.9rem;">Klik tombol untuk memilih berkas Anda</span>
        </div>

        <?php $__errorArgs = ['dokumen_lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <div class="text-danger mt-3" style="font-size: 0.85rem;"><?php echo e($message); ?></div> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <?php if(isset($employee) && $employee->dokumen_lampiran): ?>
    <div class="uploaded-files-list p-3" style="background-color: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0;">
        <div class="d-flex justify-content-between align-items-center py-2 px-3 bg-white" style="border-radius: 8px;">
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted" style="font-size: 0.85rem;">
                    <strong>Dokumen saat ini:</strong> <?php echo e(basename($employee->dokumen_lampiran)); ?>

                </span>
            </div>
            <a href="<?php echo e(asset('storage/' . $employee->dokumen_lampiran)); ?>" target="_blank" class="text-primary text-decoration-none" style="font-size: 0.85rem; font-weight: 500;">Lihat File</a>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
    document.getElementById('dokumen_lampiran').addEventListener('change', function(event) {
        var input = event.target;
        var previewText = document.getElementById('file-name-preview');
        
        // Jika ada file yang dipilih
        if (input.files && input.files[0]) {
            var fileName = input.files[0].name;
            // Ubah teks menjadi nama file dengan aksen warna primer agar terlihat jelas
            previewText.innerHTML = '<span style="color: #4f46e5; font-weight: 600;">📄 File terpilih:</span> ' + fileName;
        } else {
            // Jika user membatalkan pilihan file
            previewText.innerHTML = 'Klik tombol untuk memilih berkas Anda';
        }
    });
</script><?php /**PATH C:\ServBay\www\SIM-Karyawan\resources\views/karyawan/_form.blade.php ENDPATH**/ ?>