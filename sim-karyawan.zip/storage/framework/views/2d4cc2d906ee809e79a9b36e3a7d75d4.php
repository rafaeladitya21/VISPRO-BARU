

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header bg-white">
        <h5 class="mb-0">Edit Data Karyawan</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('karyawan.update', $employee->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('karyawan._form', ['employee' => $employee], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex justify-content-end align-items-center gap-3 mt-5 pt-3 border-top" style="border-top-color: #f1f5f9 !important;">
    <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-light px-4 py-2 text-muted" style="border-radius: 12px; font-weight: 500;">
        Batal
    </a>
    <button type="submit" class="btn btn-primary px-5 py-2">
        Simpan Data Karyawan
    </button>
</div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ServBay\www\SIM-Karyawan\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>