<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIM Karyawan Premium</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* Tipografi & Latar Belakang */
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f4f7f6; /* Warna abu-abu kebiruan yang sangat elegan */
            color: #2b3452;
        }

        /* Navbar Mewah */
        .navbar-custom {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 1rem 0;
        }
        .navbar-custom .navbar-brand {
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #ffffff;
        }

        /* Card Premium dengan Soft Shadow */
        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(15, 23, 42, 0.06);
            transition: all 0.3s ease;
        }
        .card-header {
            background-color: #ffffff;
            border-bottom: 1px solid rgba(0,0,0,0.03);
            border-radius: 16px 16px 0 0 !important;
            padding: 1.5rem;
        }
        .card-header h5 {
            font-weight: 600;
            color: #1e293b;
        }
        .card-body {
            padding: 2rem;
        }

        /* Styling Tabel Lebih Bersih */
        .table {
            color: #475569;
        }
        .table-light {
            background-color: #f8fafc;
        }
        .table-light th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            color: #64748b;
            border-bottom: 2px solid #e2e8f0;
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        .table tbody td {
            padding: 1rem 0.5rem;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        /* Tombol Elegan */
        .btn {
            border-radius: 8px;
            font-weight: 500;
            padding: 0.5rem 1.25rem;
            transition: all 0.2s ease;
            letter-spacing: 0.3px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            border: none;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            box-shadow: 0 6px 16px rgba(37, 99, 235, 0.3);
            transform: translateY(-1px);
        }
        
        /* Tombol Aksi Bawah Tabel */
        .btn-sm {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
            border-radius: 6px;
        }
        .btn-warning {
            background-color: #fef08a;
            color: #854d0e;
            border: none;
        }
        .btn-warning:hover {
            background-color: #fde047;
            color: #713f12;
        }
        .btn-danger {
            background-color: #fee2e2;
            color: #991b1b;
            border: none;
        }
        .btn-danger:hover {
            background-color: #fecaca;
            color: #7f1d1d;
        }
        
        /* Form Inputs */
        .form-control {
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            padding: 0.75rem 1rem;
            color: #334155;
            box-shadow: none;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }
        .form-label {
            font-weight: 500;
            font-size: 0.9rem;
            color: #475569;
            margin-bottom: 0.5rem;
        }

        /* Warna primer baru yang disesuaikan dengan referensi modern */
:root {
    --primary-gradient: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
    --primary-color: #4f46e5;
}

/* Penyesuaian tombol utama agar mirip tombol "Submit Request" di gambar */
.btn-primary {
    background: var(--primary-gradient);
    border: none;
    padding: 0.75rem 2rem;
    font-weight: 600;
    box-shadow: 0 4px 14px rgba(79, 70, 229, 0.25);
    border-radius: 12px;
}
.btn-primary:hover {
    background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
    box-shadow: 0 6px 20px rgba(79, 70, 229, 0.35);
    transform: translateY(-1px);
}

/* Gaya khusus label form */
.form-label {
    font-size: 0.85rem;
    font-weight: 600;
    color: #475569;
    margin-bottom: 0.4rem;
}
.form-label.required::after {
    content: " *";
    color: #ef4444;
}

/* Input Fields bergaya clean flat-elegant */
.form-control {
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    padding: 0.65rem 1rem;
    font-size: 0.95rem;
    background-color: #ffffff;
    color: #0f172a;
    transition: all 0.2s ease-in-out;
}
.form-control:focus {
    border-color: #a5b4fc;
    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.12);
    background-color: #ffffff;
}
.form-control::placeholder {
    color: #94a3b8;
    font-size: 0.9rem;
}

/* Zone Unggah Berkas Kustom */
.upload-zone {
    border: 2px dashed #cbd5e1;
    border-radius: 12px;
    background-color: #f8fafc;
    transition: all 0.2s ease;
}
.upload-zone:hover {
    border-color: var(--primary-color);
    background-color: #f5f3ff;
}
.btn-outline-primary {
    color: var(--primary-color);
    border-color: #c7d2fe;
}
.btn-outline-primary:hover {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
    color: #ffffff;
}

/* Teks Seksyen Judul */
.text-primary {
    color: var(--primary-color) !important;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom mb-5">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('karyawan.index')); ?>">
                <span class="ms-2">SIM Karyawan <span style="font-weight:300; opacity:0.8;">Premium</span></span>
            </a>
        </div>
    </nav>

    <div class="container pb-5">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" style="background-color: #dcfce7; color: #166534; border-radius: 12px;" role="alert">
                <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\ServBay\www\SIM-Karyawan\resources\views/layouts/app.blade.php ENDPATH**/ ?>