@extends('layouts.app')

@section('content')
<div class="card shadow-sm">
    <div class="card-header bg-white">
        <h5 class="mb-0">Edit Data Karyawan</h5>
    </div>
    <div class="card-body">
        <form action="{{ route('karyawan.update', $employee->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            @include('karyawan._form', ['employee' => $employee])
            <div class="d-flex justify-content-end align-items-center gap-3 mt-5 pt-3 border-top" style="border-top-color: #f1f5f9 !important;">
    <a href="{{ route('karyawan.index') }}" class="btn btn-light px-4 py-2 text-muted" style="border-radius: 12px; font-weight: 500;">
        Batal
    </a>
    <button type="submit" class="btn btn-primary px-5 py-2">
        Simpan Data Karyawan
    </button>
</div>
        </form>
    </div>
</div>
@endsection